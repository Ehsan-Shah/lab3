package comp2402w23l3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.TreeSet;

public class Part2 {

    /**
     * Read lines one at a time from r.  Outputs to w according to the
     * lab specifications.
     * Assumes every line is an integer; otherwise it throws a NumberFormatException.
     * @param r the reader to read from
     * @param w the writer to write to
     * @throws IOException, NumberFormatException
     */
    public static void execute(BufferedReader r, PrintWriter w) throws IOException, NumberFormatException {
        // Initialize variables to hold the previous line and the set of selected integers
        String line;
        Integer prevLine = null;
        TreeSet<Integer> selected = new TreeSet<>();

        // Read in the file line-by-line
        while ((line = r.readLine()) != null) {
            Integer currLine = Integer.parseInt(line);

            // If the previous line is not null and the current line is divisible by it,
            // add the current line to the set of selected integers
            if (prevLine != null && currLine % prevLine == 0) {
                selected.add(currLine);
            }

            prevLine = currLine;
        }

        // Write out the selected integers in increasing order, with ties removed
        Integer lastSelected = null;
        for (Integer num : selected) {
            if (lastSelected == null || !num.equals(lastSelected)) {
                w.println(num);
                lastSelected = num;
            }
        }
    }

    /**
     * The driver.  Open a BufferedReader and a PrintWriter, either from System.in
     * and System.out or from filenames specified on the command line, then call doIt.
     * @param args
     */
    public static void main(String[] args) {
        try {
            BufferedReader r;
            PrintWriter w;
            if (args.length == 0) {
                r = new BufferedReader(new InputStreamReader(System.in));
                w = new PrintWriter(System.out);
            } else if (args.length == 1) {
                r = new BufferedReader(new FileReader(args[0]));
                w = new PrintWriter(System.out);
            } else {
                r = new BufferedReader(new FileReader(args[0]));
                w = new PrintWriter(new FileWriter(args[1]));
            }
            long start = System.nanoTime();
            try {
                execute(r, w);
            } catch (NumberFormatException e) {
                System.err.println( "Your input must be integer only");
                System.err.println(e);
                System.exit(-1);
            }
            w.flush();
            long stop = System.nanoTime();
            System.out.println("Execution time: " + 1e-9 * (stop-start));
        } catch (IOException e) {
            System.err.println(e);
            System.exit(-2);
        }
    }
}
